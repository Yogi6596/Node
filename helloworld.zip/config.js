module.exports= {
    'secret': 'supersecret'
};