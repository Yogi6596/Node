var Rule = require('../models/ruleModel');
var Client = require('../models/clientModel');
var Service = require('../models/serviceModel');
var db = require('../database');
var _ = require('underscore');
exports.get_rules_data=function(req,res){
    Rule.forge()
    .fetchAll()
    .then(function(rule){
        res.send(rule);
    })
    .catch(function(err){
        res.send(err);
    });
}

exports.save_rules_data=function(req,res){
    var rule = new Rule();
    rule.set(req.body.rule_data)
    .save()
    .then(function(rule){
        res.send('Rule added successfully');
    })
    .catch(function(err){
        res.send(err);
    });
}

/* Method to get rules data with client data and service data i.e. for which client and which service the rule has been created */

exports.get_rules_data_by_id = function(req,res){


    /* Nested snippet for fetching data from 3 tables */

    // Rule.forge({
    //     id: req.params.rule_id
    // })
    // .fetch()
    // .then(function(rule){
    //     data = rule.toJSON();
    //     console.log(data.client_id);
    //     
    //     if(data){
    //         Client.forge({
    //             id: data.client_id
    //         })
    //         .fetch()
    //         .then(function(client){
    //             data.client = client;
    //             Service.forge({
    //                 id: data.service_id
    //             })
    //             .fetch()
    //             .then(function(service){
    //                 data.service = service;
    //                 res.send(data);
    //             })
    //            
    //         })
    //     }
        
        
    // })
    // .catch(function(err){
    //     console.log('heyy');
    //     res.send(err);
    // });

    /* snippet to fetch data from 3 tables using relationship */
    
    new Rule()
        .where('id', req.params.rule_id)
        .fetch({
            withRelated: ['client','service']
        })
        .then(function(data){
            console.log(data);
            res.json({
                data:data
            })
        })
}