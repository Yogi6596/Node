var bookshelf = require('../database');

var Client = bookshelf.Model.extend({
    tableName: 'client',
    
    // hasTimestamps :true

    rules: function(){
        return this.hasMany(Rule,'client_id');
    }
});

module.exports=Client;