var bookshelf = require('../database');
var Client = require('../models/clientModel');
var Service = require('../models/serviceModel');

var Rule = bookshelf.Model.extend({
    tableName: 'rules',

    /*************************************Use to fetch client details**********************************/
    client: function(){
        return this.belongsTo(Client,'client_id'); // means client belongs to rule
    },

    /*************************************Use to fetch service details*********************************/
    service: function(){
        return this.belongsTo(Service,'service_id'); // means service belongs to rule
    }
});

module.exports=Rule;