/***** import mysql package *****/
var mysql = require('mysql');

var connection = mysql.createConnection({
	// db credentials
	'host': 'localhost',
	'port': '3306',
	'user': 'root',
	'password': '',
	'database': 'db_samplenode'
});

connection.connect(function(error){
	if(!!error){
		console.log("Error occured---->"+error.stack);
	}else{
		console.log("Connected");
	}
});

module.exports = connection;