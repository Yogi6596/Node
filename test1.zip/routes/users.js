var express = require('express');
var router = express.Router();
var dbConnection = require('../db');
const request = require('request'); // npm install request --save 
var path    = require("path");
var express = require("express");
var app     = express();
app.use(express.static(__dirname + '/View'));

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/get', function(req, res, next) {
	var sqlQuery = "SELECT * FROM users";
	dbConnection.query(sqlQuery, function(error, rows, fields){
		if(!!error){
			res.end(error);
		}

		if(rows.length === 0){
			res.end("no rows available");
		}else{
			res.json(rows);
		}
	});
});

router.get('/get_by_id/:id',function(req,res,next){
	console.log(req.params.id);
	var sqlQuery = "SELECT * FROM rules WHERE id="+req.params.id;
	dbConnection.query(sqlQuery, function(error, rows, fields){
		if(!!error){
			res.end(error);
		}

		if(rows.length === 0){
			res.end("no rows available");
		}else{
			res.json(rows);
		}
	});
});

router.get('/get_client',function(req,res,next){
	var sqlQuery = "SELECT * from client";
	dbConnection.query(sqlQuery, function(error,rows,fields){
		if(rows.length === 0){
			res.json('No Rows Available');
		}else{
			res.json(rows);
		}
	})
});

router.post('/add_client',function(req,res,next){
	var sqlQuery = "INSERT INTO test (first_name,last_name) VALUES ('yogita','gawande')";
	dbConnection.query(sqlQuery, function(error,rows,fields){
		if(error){
			res.json('Error');
		}else{
			res.json('Saved');
		}
	})
});

router.post('/add_client_object',function(req,res,next){
	var postData = req.body;
	var sqlQuery = "INSERT INTO test SET ?";
	for(var i=0;i<postData.length;i++){
		dbConnection.query(sqlQuery, [postData[i]], function(error, rows, fields){
		if(!!error){
			console.log(error);
			res.end(error);
		}else{
			console.log(rows);
			res.end("creted new entry");
		}
	});
	}
});

router.post('/update_client',function(req,res,next){
	var postData = req.body;
	var sqlQuery = "UPDATE test SET ? WHERE id=" +req.body.id;
	dbConnection.query(sqlQuery,[postData], function(error,rows,fields){
		if(error){
			res.json('Error');
		}else{
			res.json('Saved');
		}
	})
});

router.get('/delete/:id',function(req,res,next){
	dbConnection.query("DELETE FROM test WHERE id="+req.params.id, function(error,rows,fields){
		if(error){
			res.json('Error');
		}else{
			res.json('deleted');
		}
	})
});

router.get('/get_weather',function(req,res,next){
	let apiKey = 'a3209c86ec5cc63095f328c08fed7cd6';
    let city = 'Nagpur';
    let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`

    request(url, function (err, response, body) {
        if(err){
            console.log('error:', error);
        } else {
            console.log('body:', body);
            res.send(JSON.parse(body));
        }
    });
});

router.get('/home',function(req,res){
  res.sendFile('/home/tecture17/test1/index.html');
  //__dirname : It will resolve to your project folder.
});

module.exports = router;
